# -*- coding: utf-8 -*-
"""
Created on Wed Dec  5 17:46:50 2018

@author: yang
"""



from seq2seq_model import Model
import tensorflow as tf
import pickle
import os
import argparse

import numpy as np



def get_absolute_trajectory(traj):
    '''
    Function that computes the absolute coordinates of the trajectory
    traj: (10,7)
    '''
    new_traj=np.zeros([len(traj),1])
    
    for i in range(len(traj)):
         
        real_lat=traj[i,0]*(traj[i,1]-traj[i,2])+traj[i,2]  # lat        
        new_traj[i,0]=real_lat

    return new_traj
    


def get_mean_lat_error(predicted_traj, true_traj, observed_length):
    # The data structure to store all errors
    error = np.zeros(len(true_traj) - observed_length)
    # For each point in the predicted part of the trajectory
    for i in range(observed_length, len(true_traj)):
        # The predicted position
        pred_pos = predicted_traj[i, 0:1]
        # The true position
        true_pos = true_traj[i, 0:1]

        # The euclidean distance is the error
        error[i-observed_length] = np.linalg.norm(true_pos - pred_pos)

    # Return the mean error
    return np.mean(error)





#%% basic parameters

parser=argparse.ArgumentParser()

parser.add_argument('--model_checkpoint', type=str, default=None,help='model checkpoint')
                    
parser.add_argument('--saving_path', type=str, default=None, help='saving path')
                    
parser.add_argument('--epoch', type=str, default=None, help='epoch')


#parser.add_argument('--model_checkpoint', type=str, default='epoch_50_model.ckpt-3500.index',help='model checkpoint')
#                    
#parser.add_argument('--saving_path', type=str, default='save0', help='saving path')
#                    
#parser.add_argument('--epoch', type=str, default='35', help='epoch')


parser.add_argument('--eval_res', type=str, default='eval_tmp.txt',help='eval_res')


args=parser.parse_args()

tf.reset_default_graph()


#%% Test

if __name__ == '__main__':

    #-------------------------------------- parameters setting----------------------------------#
    
    model_checkpoint = args.model_checkpoint
    model_checkpoint = model_checkpoint[:-6] # eg. epoch_2_model.ckpt-196.index -> eg. epoch_2_model.ckpt-196
    print("model_checkpoint:", model_checkpoint)
    saving_path = args.saving_path
    

    with open(os.path.join(saving_path, 'config.pkl'), 'rb') as fid: 
        saved_args = pickle.load(fid)
    print('saved_args',saved_args)
    
    epoch = args.epoch
    eval_res_file = args.eval_res
 
    #------------------------------------Loading cache ------------------------#


    # load the test data
    test_X_cache = os.path.join(saving_path, 'test_X.pkl')
    test_Y_cache = os.path.join(saving_path, 'test_Y.pkl')
    
    with open(test_X_cache, 'rb') as fid:
        test_input = pickle.load(fid)
    with open(test_Y_cache, 'rb') as fid:
        test_output = pickle.load(fid)
        
    test_input0=np.array(test_input)
    test_output0=np.array(test_output)

    print('shape(test_input0):',np.shape(test_input0)) #[298,8,3]
    
    
    test_input1=test_input0[:,:,0:1]
    test_output1=test_output0[:,:,0:1]
    
    test_input2=test_input1[:,:,0] #[,obs_len]
    test_output2=test_output1[:,:,0]   #[,pre_len]
    
    
    # load the model
    rnn_model_test = Model(saved_args, feed_previous=True)
    
    sess = tf.InteractiveSession() #Initialize TensorFlow session
    
    sess.run(tf.global_variables_initializer())
    
    saver = rnn_model_test.saver.restore(sess, model_checkpoint)



    lat_error_inv=0.0
    lat_error_inv_fp=0.0   

    error_each_lat_inv=0.0
    error_each_lat_inv_fp=0.0
    
    
    
    for j in range(len(test_input0)):
        
        test_seq_input_1=test_input2[j]
        test_seq_output_1=test_output2[j]
        
        feed_dict = {rnn_model_test.enc_inp[t]: test_seq_input_1[t].reshape(1, 1) for t in range(saved_args.obs_length)}
        feed_dict.update({rnn_model_test.target_seq[t]: np.zeros([1, saved_args.output_dim], dtype=np.float32) for t in range(saved_args.pred_length)})
        final_preds = sess.run(rnn_model_test.reshaped_outputs, feed_dict)
        final_preds = np.concatenate(final_preds, axis = 1)
        final_preds=final_preds.reshape(-1)
        
        #-----------------error with inverse-normalization---------------#
        
        temp_input0=np.reshape(test_input0[j,:,0:3],[-1,3]) # [,3]
        temp_output0=np.reshape(test_output0[j,:,0:3],[-1,3]) #[,3]
    
        # get the oringinal trajectory
        
        pred_gt_traj_inv=get_absolute_trajectory(temp_output0) # only prediction part-GT

        temp_final_preds=np.c_[np.reshape(final_preds,[-1,1]),temp_output0[:,1:3]] #[8,3]
        
        pred_traj_inv=get_absolute_trajectory(temp_final_preds)  # only prediction part-Prediction
        
        lat_error_inv+=get_mean_lat_error(pred_gt_traj_inv, pred_traj_inv, 0)
        lat_error_inv_fp+=get_mean_lat_error(pred_gt_traj_inv, pred_traj_inv, saved_args.pred_length-1)
        
        
       
    error_each_lat_inv=lat_error_inv/test_input0.shape[0] # lat
    error_each_lat_inv_fp=lat_error_inv_fp/test_input0.shape[0] # final points pf the lat
  
    print('error_each_lat_inv:{}'.format(error_each_lat_inv))
    print('error_each_lat_inv_fp:{}'.format(error_each_lat_inv_fp))
    print('\n')



   
    with open(eval_res_file,'w') as fid:
         # write into the file
        str_res= epoch+","+str(error_each_lat_inv)+","+str(error_each_lat_inv_fp)+'\n'
        print("str_res:", str_res)
        fid.write(str_res)
   
    
    
