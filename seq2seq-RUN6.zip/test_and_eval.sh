#!/usr/bin/env bash
k_folds=5

training_total_epoch=121
saving_every_epoch=5
eval_res_file="eval_res.txt"

for k in $(seq $k_folds)
do
    let k=k-1
    let temp_s=k_folds-1

    echo "**************** testing ${k}-th fold ******************"
    saving_path="save${k}"
    eval_res_cache_old="${saving_path}/${eval_res_file}"
    if [[ eval_res_cache_old ]]; then
    	#statements
    	rm -r $eval_res_cache_old
    fi
    saving_path="save${k}"
    # remove the previous eval_res_cache
    eval_res_cache_old="${saving_path}/${eval_res_file}"
    rm -r $eval_res_cache_old
    eval_res_cache="${saving_path}/${eval_res_file}"
    training_loss_cache="$saving_path/training_loss_info.txt"

if true;then
    # testing and evaluating each epoch model
    for epoch in $(seq $training_total_epoch)
    do
        let a=epoch%$saving_every_epoch
        if [ $a -eq 0 ];then
            echo "testing epoch:", $epoch
            
            model_checkpoint=`ls $saving_path/epoch_${epoch}_model.ckpt*.index`
            echo $model_checkpoint
            if [ -z ${model_checkpoint} ];then
                echo "models at epoch ${epoch} have not been generated!"
                continue
            fi
            eval_tmp='tmp_eval_res.txt'
            python test_and_eval.py \
                --epoch ${epoch} \
                --saving_path ${saving_path} \
                --model_checkpoint ${model_checkpoint} \
                --eval_res ${eval_tmp}
            cat $eval_tmp >> $eval_res_cache  #saving evaluating result of each epoch into final file 
        fi
    done
fi

    #visualizing training loss and evaluating results
#    python vis_training_eval_loss.py \
#        --training_loss_cache ${training_loss_cache} \
#        --eval_res_cache ${eval_res_cache}


done
