# -*- coding: utf-8 -*-
"""
Created on Thu Oct  4 11:58:14 2018

@author: yang
"""

import numpy as np

import argparse


parser=argparse.ArgumentParser()
parser.add_argument('--file', type=str, default=None,
                    help='eval_res')                 
args=parser.parse_args()
data=np.loadtxt(args.file,delimiter=',')
lat_error_each_inv=np.mean(data[:,1])
lat_error_each_inv_fp=np.mean(data[:,2])

print('*********************Average of All Folds***********************\n')

print('mean error-lat traj:{}'.format(lat_error_each_inv))
print('mean error-lat traj-final point:{}'.format(lat_error_each_inv_fp))
